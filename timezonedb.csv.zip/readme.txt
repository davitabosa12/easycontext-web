World Time Zone Database
========================

Source : http://www.iana.org
Processed by : http://timezonedb.com

This work is licensed under a Creative Commons Attribution 3.0 License,
see http://creativecommons.org/licenses/by/3.0/
The Data is provided "as is" without warranty or any representation of accuracy, timeliness or completeness.