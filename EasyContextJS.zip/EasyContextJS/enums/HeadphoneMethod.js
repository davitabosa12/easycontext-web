const HeadphoneMethod = {
    PLUGGING_IN : "HEADPHONE.PLUGGING_IN",
    UNPLUGGING: "HEADPHONE.UNPLUGGING",
    DURING: "HEADPHONE.DURING",
}

export default HeadphoneMethod;
