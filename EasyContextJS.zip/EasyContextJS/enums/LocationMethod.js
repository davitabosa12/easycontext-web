const LocationMethod = {
    ENTERING: "LOCATION.ENTERING",
    EXITING: "LOCATION.EXITING",
    IN: "LOCATION.IN",
}

export default LocationMethod;
