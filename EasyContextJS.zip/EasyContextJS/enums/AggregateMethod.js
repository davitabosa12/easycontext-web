const AggregateMethod = {

    AND: "AGGREGATE.AND",
    NOT: "AGGREGATE.NOT",
    OR: "AGGREGATE.OR"
}

export default AggregateMethod;