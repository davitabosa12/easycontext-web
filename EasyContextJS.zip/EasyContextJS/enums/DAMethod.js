const DAMethod = {
    STARTING: "DA.STARTING",
    STOPPING: "DA.STOPPING",
    DURING: "DA.DURING",
}

export default DAMethod;