export default class Action{
    constructor(klassName){
        this.className = klassName;
    }
}